def countstring(str):

    length = len(str)
    answer = length * length(+1)//2
    return answer;

def main():
    str = input()
    print(countstring(str))

main()
